//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by KeyBoard.rc
//
#define IDC_EDIT_KEYBOARD               1000
#define IDD_DIALOG_KEYBOARD             1000
#define IDC_BTN_OK                      1001
#define IDD_DIALOG_KEYPAD               1001
#define IDC_BTN_CANCEL                  1002
#define IDC_MSG_KEYBOARD                1003
#define IDC_MSG_MIN                     1004
#define IDC_MSG_MIN_DATA                1005
#define IDC_MSG_MAX                     1006
#define IDC_MSG_MAX_DATA                1007
#define IDC_MSG_CURRENT                 1008
#define IDC_MSG_CURRENT_DATA            1009
#define IDC_MSG_NEW                     1010
#define IDC_EDIT_NEW                    1011
#define IDC_BTN_CLEAR                   1012
#define IDC_MSG_KEYPAD                  1013
#define IDD_DIALOG1                     2000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        2001
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         2000
#define _APS_NEXT_SYMED_VALUE           2000
#endif
#endif
