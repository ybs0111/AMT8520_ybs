//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ManagerSocket.rc
//
#define IDD_DIALOG_ADD                  1000
#define IDC_BTN_ADD                     1001
#define IDB_BITMAP_ADD                  1002
#define IDC_BTN_EXIT                    1002
#define IDB_BITMAP_DEL                  1003
#define IDC_MSG_SERIAL                  1003
#define IDD_DIALOG_MANAGER_SOCKET       1004
#define IDC_MSG_SERIAL_DATA             1004
#define IDC_MSG_HIFIX                   1005
#define IDC_MSG_HIFIX_DATA              1006
#define IDC_MSG_COUNT                   1007
#define IDC_GROUP_SOCKET                1007
#define IDC_MSG_COUNT_DATA              1008
#define IDC_BTN_SOCKET_INSERT           1008
#define IDC_GROUP_MANAGER               1009
#define IDC_MSG_SLOT                    1010
#define IDC_MSG_SLOT_DATA               1011
#define IDC_MSG_COUNT_1                 1012
#define IDC_MSG_COUNT_DATA_1            1013
#define IDC_BTN_SOCKET_REMOVE           1014
#define IDC_BTN_ADD_SOCKET              1015
#define IDC_BTN_DELETE_SOCKET           1016
#define IDC_MSG_HIFIX_NUM               1017
#define IDC_MSG_HIFIX_NUM_DATA          1018
#define IDC_CUSTOM_MANAGER              1019
#define IDC_CUSTOM_SOCKET               1020
#define IDC_CUSTOM_HIFIX                1021
#define IDC_COMBO_HIFIX                 1022
#define IDC_BTN_APPLY                   1023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1006
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           1000
#endif
#endif
