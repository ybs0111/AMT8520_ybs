//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by XgemInterface.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_XGEMINTERFACE_DIALOG        102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDI_ICON1                       129
#define IDC_CURSOR1                     130
#define IDR_MENU                        135
#define IDI_ICON2                       138
#define IDI_ICON3                       139
#define IDI_ICON4                       140
#define IDC_MSG_HOST_CONNECTOR          1000
#define IDC_MSG_HOST_CONNECTOR_STATUS   1001
#define IDC_MSG_EQ_CONNECTOR            1002
#define IDC_MSG_EQ_CONNECT_STATUS       1003
#define IDC_MSG_MACHINE_STATUS          1003
#define IDC_EXGEMCTRL_GEM               1004
#define IDC_LIST1                       1006
#define IDC_LIST_DATA                   1006
#define IDC_BTN_HIDE                    1007
#define IDC_EXCOMCTRL31                 1008
#define IDC_BUTTON1                     1009
#define ID_VIEW                         32771
#define ID_EXIT                         32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
